ALTER TABLE `empresas` ADD `puestoynumcompro` VARCHAR(50) NULL;
